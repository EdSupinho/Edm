﻿using Newtonsoft.Json;
using PrevisaoTemperatura.Models;

namespace PrevisaoTemperatura.Services
{
    public class WeatherService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;
        private readonly string _baseUrl;

        public WeatherService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _apiKey = configuration["OpenWeatherMap:ApiKey"]; // Você precisa configurar isso no appsettings.json
            _baseUrl = "https://api.openweathermap.org/data/2.5";
        }

        // Método para pegar a temperatura atual
        public async Task<Temperatura?> GetTemperaturaAtualAsync(string cidade)
        {
            try
            {
                var url = $"{_baseUrl}/weather?q={cidade}&appid={_apiKey}&units=metric&lang=pt";
                var response = await _httpClient.GetStringAsync(url);
                var weatherData = JsonConvert.DeserializeObject<dynamic>(response);

                if (weatherData != null)
                {
                    return new Temperatura
                    {
                        Cidade = weatherData.name,
                        Pais = weatherData.sys.country,
                        TemperaturaAtual = Math.Round((double)weatherData.main.temp, 1),
                        TemperaturaMinima = Math.Round((double)weatherData.main.temp_min, 1),
                        TemperaturaMaxima = Math.Round((double)weatherData.main.temp_max, 1),
                        Descricao = weatherData.weather[0].description,
                        Umidade = weatherData.main.humidity,
                        VelocidadeVento = Math.Round((double)weatherData.wind.speed * 3.6, 1), // Converter m/s para km/h
                        IconeClima = weatherData.weather[0].icon,
                        Latitude = weatherData.coord.lat,
                        Longitude = weatherData.coord.lon,
                        DataConsulta = DateTime.Now
                    };
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao buscar temperatura atual: {ex.Message}");
            }

            return null;
        }

        // Método para pegar a previsão dos próximos 5 dias
        public async Task<List<dynamic>?> GetPrevisao5DiasAsync(string cidade)
        {
            try
            {
                var url = $"{_baseUrl}/forecast?q={cidade}&appid={_apiKey}&units=metric&lang=pt";
                var response = await _httpClient.GetStringAsync(url);
                var forecastData = JsonConvert.DeserializeObject<dynamic>(response);

                if (forecastData != null)
                {
                    var previsoes = new List<dynamic>();

                    // Agrupar por dia e pegar o horário mais próximo de 12h
                    var dadosAgrupados = ((IEnumerable<dynamic>)forecastData.list)
                        .GroupBy(item => DateTime.Parse((string)item.dt_txt).Date)
                        .Select(grupo =>
                            grupo.OrderBy(item =>
                                Math.Abs((DateTime.Parse((string)item.dt_txt) - grupo.Key.AddHours(12)).TotalHours)
                            ).First()
                        )
                        .Take(5); // Pegar apenas 5 dias

                    foreach (var item in dadosAgrupados)
                    {
                        previsoes.Add(new
                        {
                            Data = DateTime.Parse((string)item.dt_txt),
                            Temperatura = Math.Round((double)item.main.temp, 1),
                            TemperaturaMinima = Math.Round((double)item.main.temp_min, 1),
                            TemperaturaMaxima = Math.Round((double)item.main.temp_max, 1),
                            Descricao = (string)item.weather[0].description,
                            Icone = (string)item.weather[0].icon,
                            Umidade = (int)item.main.humidity,
                            VelocidadeVento = Math.Round((double)item.wind.speed * 3.6, 1) // m/s para km/h
                        });
                    }

                    return previsoes;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao buscar previsão: {ex.Message}");
            }

            return null;
        }
    }
}
