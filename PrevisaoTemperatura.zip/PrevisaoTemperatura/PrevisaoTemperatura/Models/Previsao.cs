﻿using System.ComponentModel.DataAnnotations;

namespace PrevisaoTemperatura.Models
{
    public class Previsao
    {
        public int Id { get; set; }
        public DateTime Data { get; set; }
        public string Condicao { get; set; }
        public double TemperaturaMin { get; set; }
        public double TemperaturaMax { get; set; }
        public string Cidade { get; set; }
    }
}
