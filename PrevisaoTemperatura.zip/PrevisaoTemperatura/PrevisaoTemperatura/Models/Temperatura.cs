﻿using System.ComponentModel.DataAnnotations;

namespace PrevisaoTemperatura.Models
{
    public class Temperatura
    {
        public int Id { get; set; }

        [Required]
        public string Cidade { get; set; }

        [Required]
        public double TemperaturaAtual { get; set; }

        public double TemperaturaMinima { get; set; }

        public double TemperaturaMaxima { get; set; }

        [Required]
        public string Descricao { get; set; }

        public int Umidade { get; set; }

        public double VelocidadeVento { get; set; }

        public DateTime DataConsulta { get; set; }

        public string Pais { get; set; }

        // Campos para armazenar dados da API
        public string IconeClima { get; set; }

        public double Latitude { get; set; }

        public double Longitude { get; set; }
    }
}