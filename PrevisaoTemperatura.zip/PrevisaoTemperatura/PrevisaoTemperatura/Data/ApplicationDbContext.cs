﻿using Microsoft.EntityFrameworkCore;
using PrevisaoTemperatura.Models;

namespace PrevisaoTemperatura.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Temperatura> Temperaturas { get; set; }
        public DbSet<Previsao> Previsoes { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configurações adicionais da tabela
            modelBuilder.Entity<Temperatura>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Cidade).HasMaxLength(100).IsRequired();
                entity.Property(e => e.Descricao).HasMaxLength(200);
                entity.Property(e => e.Pais).HasMaxLength(50);
                entity.Property(e => e.IconeClima).HasMaxLength(50);
                entity.Property(e => e.TemperaturaAtual).HasPrecision(5, 2);
                entity.Property(e => e.TemperaturaMinima).HasPrecision(5, 2);
                entity.Property(e => e.TemperaturaMaxima).HasPrecision(5, 2);
                entity.Property(e => e.VelocidadeVento).HasPrecision(5, 2);
                entity.Property(e => e.Latitude).HasPrecision(9, 6);
                entity.Property(e => e.Longitude).HasPrecision(9, 6);
            });
        }
    }
}