﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PrevisaoTemperatura.Data;
using PrevisaoTemperatura.Models;
using PrevisaoTemperatura.Services;

namespace PrevisaoTemperatura.Controllers
{
    public class TemperaturaController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly WeatherService _weatherService;

        public TemperaturaController(ApplicationDbContext context, WeatherService weatherService)
        {
            _context = context;
            _weatherService = weatherService;
        }

        // GET: Temperatura
        public async Task<IActionResult> Index()
        {
            var temperaturas = await _context.Temperaturas
                .OrderByDescending(t => t.DataConsulta)
                .ToListAsync();
            return View(temperaturas);
        }

        // GET: Temperatura/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var temperatura = await _context.Temperaturas
                .FirstOrDefaultAsync(m => m.Id == id);

            if (temperatura == null)
            {
                return NotFound();
            }

            return View(temperatura);
        }

        // GET: Temperatura/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Temperatura/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Cidade")] Temperatura temperatura)
        {
            if (!string.IsNullOrWhiteSpace(temperatura.Cidade))
            {
                var dadosClima = await _weatherService.GetTemperaturaAtualAsync(temperatura.Cidade);

                if (dadosClima != null)
                {
                    _context.Add(dadosClima);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ModelState.AddModelError("", "Cidade não encontrada ou erro na API");
                }
            }

            return View(temperatura);
        }

        // GET: Temperatura/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var temperatura = await _context.Temperaturas.FindAsync(id);
            if (temperatura == null)
            {
                return NotFound();
            }
            return View(temperatura);
        }

        // POST: Temperatura/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Cidade,TemperaturaAtual,TemperaturaMinima,TemperaturaMaxima,Descricao,Umidade,VelocidadeVento,DataConsulta,Pais,IconeClima,Latitude,Longitude")] Temperatura temperatura)
        {
            if (id != temperatura.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(temperatura);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TemperaturaExists(temperatura.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(temperatura);
        }

        // GET: Temperatura/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var temperatura = await _context.Temperaturas
                .FirstOrDefaultAsync(m => m.Id == id);
            if (temperatura == null)
            {
                return NotFound();
            }

            return View(temperatura);
        }

        // POST: Temperatura/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var temperatura = await _context.Temperaturas.FindAsync(id);
            if (temperatura != null)
            {
                _context.Temperaturas.Remove(temperatura);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Temperatura/Atual
        public IActionResult Atual()
        {
            return View();
        }

        // POST: Temperatura/Atual
        [HttpPost]
        public async Task<IActionResult> BuscarAtual(string cidade)
        {
            if (string.IsNullOrWhiteSpace(cidade))
            {
                ViewBag.Erro = "Por favor, informe uma cidade";
                return View("Atual");
            }

            var temperatura = await _weatherService.GetTemperaturaAtualAsync(cidade);

            if (temperatura == null)
            {
                ViewBag.Erro = "Cidade não encontrada ou erro na API";
                return View("Atual");
            }

            return View("Atual", temperatura);
        }

        // GET: Temperatura/Previsao
        public async Task<IActionResult> Previsao(string cidade)
        {
            ViewBag.Cidade = cidade;

            if (string.IsNullOrWhiteSpace(cidade))
            {
                return View();
            }

            var previsoes = await _weatherService.GetPrevisao5DiasAsync(cidade);
            return View(previsoes);
        }

        private bool TemperaturaExists(int id)
        {
            return _context.Temperaturas.Any(e => e.Id == id);
        }


        // POST: Temperatura/SalvarPrevisao
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SalvarPrevisao(string cidade)
        {
            if (string.IsNullOrWhiteSpace(cidade))
            {
                return BadRequest("A cidade não pode estar vazia.");
            }

            var previsoes = await _weatherService.GetPrevisao5DiasAsync(cidade);
            if (previsoes == null || !previsoes.Any())
            {
                return NotFound("Nenhuma previsão disponível para salvar.");
            }

            foreach (var p in previsoes)
            {
                _context.Previsoes.Add(new Previsao
                {
                    Data = p.Data,
                    Condicao = p.Descricao,
                    TemperaturaMin = p.TemperaturaMinima,
                    TemperaturaMax = p.TemperaturaMaxima,
                    Cidade = cidade
                });
            }

            await _context.SaveChangesAsync();
            return RedirectToAction("Historico", "Previsao"); // Redireciona para o histórico do PrevisaoController
        }
    }
}
