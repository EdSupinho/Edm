﻿using Microsoft.AspNetCore.Mvc;
using PrevisaoTemperatura.Data;
using PrevisaoTemperatura.Models;
using PrevisaoTemperatura.Services;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace PrevisaoTemperatura.Controllers
{
    public class PrevisaoController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly WeatherService _weatherService;

        public PrevisaoController(ApplicationDbContext context, WeatherService weatherService)
        {
            _context = context;
            _weatherService = weatherService;
        }

        // Exibir previsões salvas
        public IActionResult Historico()
        {
            var previsoes = _context.Previsoes
                .OrderByDescending(p => p.Data)
                .ToList();
            return View(previsoes);
        }

        // Buscar previsão de 5 dias e salvar
        public async Task<IActionResult> Atualizar(string cidade = "Maputo")
        {
            var previsoes = await _weatherService.GetPrevisao5DiasAsync(cidade);

            foreach (var p in previsoes)
            {
                _context.Previsoes.Add(new Previsao
                {
                    Data = p.Data,
                    Condicao = p.Condicao,
                    TemperaturaMin = p.TempMin,
                    TemperaturaMax = p.TempMax,
                    Cidade = cidade
                });
            }

            await _context.SaveChangesAsync();

            return RedirectToAction("Historico");
        }
    }
}
